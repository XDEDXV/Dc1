const express = require('express');
const fs = require('fs-extra');
const app = express();

app.use(express.json());
app.use(express.static('public'));

app.get('/api/files', async (req, res) => {
  const files = await fs.readdir('./files');
  res.json(files);
});

app.listen(3000, () => console.log('Web panel running on port 3000'));
