# FULL HOSTING VERSION

## Run everything

npm install express fs-extra

node server.js

Open:
http://localhost:3000

Works on phone if hosted (Railway/Render/VPS)
